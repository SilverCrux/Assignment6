package silvercrux;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableCellRenderer;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import java.util.ArrayList;


import javax.swing.JLabel;
import javax.security.auth.login.LoginContext;
import javax.sound.midi.Instrument;
import javax.sound.midi.MidiDevice.Info;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.DefaultCellEditor;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;

public class MainGUI_2014302580187 extends JFrame {

	public static JPanel contentPane; //商店页面
	public static JPanel loginPane;  //登录页面
	public static JTextField name = new JTextField(20);  //登录页面中用户名
	public static JTextField password = new JTextField(20);  //登录页面中密码
	public JPanel cartPane;  //购物车页面
	private JTable table;  //商店表格
	private JTable cartTable; //购物车表格
	private JTable userTable;  //用户信息表格
	public static String userName;  //用户名
    public static InfoReader infoReader;  //从数据库中读取数据
    public static JScrollPane scrollPane;  
    public static JLabel lblNewLabel_2;
	/**
	 * Launch the application.
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
      				MainGUI_2014302580187 frame = new MainGUI_2014302580187();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public MainGUI_2014302580187() throws ClassNotFoundException, SQLException {
		infoReader = new InfoReader();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 717, 425);
		setLoginPane();
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setVisible(false);
		contentPane.setLayout(new BorderLayout(0, 0));
	
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.WEST);
		
		scrollPane = setShopTable();
	    contentPane.add(scrollPane, BorderLayout.CENTER);
		
	    panel.setLayout(new GridLayout(8, 1));
		JLabel lblNewLabel = new JLabel("SilverCrux宠物商店");
		panel.add(lblNewLabel);
		JButton userButton = new JButton("用户信息");
		userButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				contentPane.setVisible(false);
				try {
					setUserPane();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(userButton);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(new GridLayout(4, 1));
		contentPane.add(panel_1, BorderLayout.EAST);
		
		JLabel lblNewLabel_1 = new JLabel("用户名");
		panel_1.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel(userName);
		panel_1.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("购物车");
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					setCartPane();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
				});
				
		panel_1.add(btnNewButton);
		
		JButton addToCartButton = new JButton("加入购物车");
		addToCartButton.addActionListener(new CartButtonController(table));
		panel_1.add(addToCartButton);
		
	}

	//绘制登录页面
	public void setLoginPane()
	{
		loginPane = new JPanel();
		loginPane.setLayout(new BorderLayout(0,0));
		JPanel namePanel = new JPanel();
		namePanel.add(new JLabel("用户名"));
		namePanel.add(name);
		JPanel passwordPanel = new JPanel();
		passwordPanel.add(new JLabel("密码"));
		passwordPanel.add(password);
		JPanel inputPanel = new JPanel();
		inputPanel.setLayout(new GridLayout(2, 1));
		inputPanel.add(namePanel);
		inputPanel.add(passwordPanel);
		JPanel buttonPanel = new JPanel();
		JButton login = new JButton("登录");
		login.addActionListener(new LoginButtonController(this));
		login.setBounds(10, 10, 10, 10);
		JButton regist = new JButton("注册");
		regist.addActionListener(new RegistButtonController(this));
		regist.setBounds(10, 10, 10, 10);
		buttonPanel.add(login);
		buttonPanel.add(regist);
		loginPane.add(inputPanel, BorderLayout.CENTER);
		loginPane.add(buttonPanel, BorderLayout.SOUTH);
		setContentPane(loginPane);
	}
	
	//绘制购物车页面
	public void setCartPane() throws SQLException
	{
		contentPane.setVisible(false);
		JPanel panel_2 = new JPanel();
        panel_2.setLayout(new GridLayout(6, 1));
		JLabel lblNewLabel = new JLabel("SilverCrux宠物商店");
		panel_2.add(lblNewLabel);
		panel_2.add(new JLabel("您的购物车"));
		JButton buyButton = new JButton("购买");
		try {
			setCartTable();
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		buyButton.addActionListener(new PerchaseButtonController(cartTable,this));
		JButton clearButton = new JButton("清空");
		clearButton .addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				java.sql.Connection connection;
				try {
					connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
					java.sql.Statement statement = connection.createStatement();
					MainGUI_2014302580187.infoReader.setPetsCart(true);
					statement.execute("truncate table 2014302580187_cart");
					cartPane.setVisible(false);					
					contentPane.setVisible(true);
					setContentPane(contentPane);
					setCartPane();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}								
			}
		});
		
		panel_2.add(buyButton);
		panel_2.add(clearButton);
		JButton backButton = new JButton("返回");
		
		backButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cartPane.setVisible(false);					
				contentPane.setVisible(true);
				setContentPane(contentPane);
			}
		});
		
		JScrollPane cartScrollPane = new JScrollPane();
		try {
			cartScrollPane = setCartTable();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
	    panel_2.add(new Label(""));
		panel_2.add(backButton);
		
		cartPane = new JPanel();
		cartPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(cartPane);
		cartPane.setLayout(new BorderLayout(0, 0));
		cartPane.add(panel_2, BorderLayout.WEST);
		cartPane.add(cartScrollPane, BorderLayout.CENTER);
	}
	
	//绘制用户信息页面
	public void setUserPane() throws SQLException
	{
		JPanel userPane = new JPanel();
		userPane.setLayout(new BorderLayout());
		JPanel InfoPane = new JPanel();
		InfoPane.setLayout(new GridLayout(8, 1));
		JLabel accountName = new JLabel(userName);
		JButton backButton = new JButton("返回");
		backButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				userPane.setVisible(false);					
				contentPane.setVisible(true);
				setContentPane(contentPane);
			}
		});
		InfoPane.add(new JLabel(""));
		InfoPane.add(new JLabel(userName));
		InfoPane.add(new JLabel(""));
		InfoPane.add(new JLabel(""));
		InfoPane.add(new JLabel(""));
		InfoPane.add(backButton);
		userPane.add(InfoPane, BorderLayout.WEST);
		JScrollPane userScrollPane = new JScrollPane();
		userScrollPane = setUserTable();
		userPane.add(userScrollPane,BorderLayout.CENTER);
		userPane.setVisible(true);
		setContentPane(userPane);
	}
	
	//登录功能
	public void Login()
	{
		loginPane.setVisible(false);
		contentPane.setVisible(true);
		setContentPane(contentPane);
	}
	
	
	//绘制购物车表格
	public JScrollPane setCartTable() throws SQLException
	{
	    String[] firstCartRow = {
	    		"name",
			    "eat",
			    "drink",
			    "live",
			    "hobby",
			    "number"
	    };
	    infoReader.setPetsCart();
	    Object[][] cartRow = infoReader.getPetsCart();
	    cartTable = new JTable(cartRow,firstCartRow);
	    JScrollPane cartScrollPane = new JScrollPane(cartTable);
	    cartTable.setFillsViewportHeight(true);
	    return cartScrollPane;
	}
	
	//绘制商店表格
	public JScrollPane setShopTable() throws SQLException
	{
		 String[] firstShopRow = {
				    "name",
				    "eat",
				    "drink",
				    "live",
				    "hobby",
				    "minus",
				    "number",
				    "add"
		    };
		    Object[][] petRow = infoReader.getPetsRow();
		
		    table = new JTable(petRow,firstShopRow);
		    table.getColumnModel().getColumn(5).setCellRenderer(new ButtonRenderer());
		    table.getColumnModel().getColumn(5).setCellEditor(new ButtonEditor(table,"-"));
		    table.getColumnModel().getColumn(7).setCellRenderer(new ButtonRenderer());
		    table.getColumnModel().getColumn(7).setCellEditor(new ButtonEditor(table,"+"));
		    table.setRowSelectionAllowed(false);
		    JScrollPane scrollPaneTmp = new JScrollPane(table);
		    table.setFillsViewportHeight(true);
			return scrollPaneTmp;
	}
	
	//绘制用户信息表格
	public JScrollPane setUserTable() throws SQLException
	{
		String firstUserRow[] = {
				"name",
			    "eat",
			    "drink",
			    "live",
			    "hobby",
			    "number", 
		};
		infoReader.setUserPets();
		Object[][] userPets = infoReader.getUserPets();
		userTable= new JTable(userPets,firstUserRow);
	    JScrollPane userScrollPaneTmp = new JScrollPane(userTable);
	    userTable.setFillsViewportHeight(true);
	    return userScrollPaneTmp;	
	}
}



