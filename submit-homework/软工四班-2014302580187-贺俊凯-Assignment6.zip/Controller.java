package silvercrux;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTable;

//在商店页面中的加号和减号实现更改物品数量
class ButtonController implements ActionListener
{

	private String str;
	private JTable table;
	public ButtonController(JTable table,String str) {
		// TODO Auto-generated constructor stub
		this.str = str;
		this.table = table;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		int row = table.getSelectedRow();
		if(str.equals("-")&&Integer.parseInt(table.getValueAt(row, 6).toString())>0)
		{
			table.setValueAt(Integer.parseInt(table.getValueAt(row, 6).toString())-1, row, 6);
		}
		if(str.equals("+"))
		    table.setValueAt(Integer.parseInt(table.getValueAt(row, 6).toString())+1, row, 6);
	}
	
}


//购买并清空购物车
class PerchaseButtonController implements ActionListener
{
	JTable table;
	MainGUI_2014302580187 frame;
	public PerchaseButtonController(JTable table,MainGUI_2014302580187 frame) {
		// TODO Auto-generated constructor stub
		this.table = table;
		this.frame = frame;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		try {
			
			java.sql.Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			java.sql.Statement statement = connection.createStatement();
			
			int rownum = 0;
			for(;rownum<table.getRowCount();rownum++)
			{
				int num = Integer.parseInt(table.getModel().getValueAt(rownum,5).toString());
				if(num==0)
					continue;
				String str = "select number from 2014302580187_userInfo where name='"+table.getModel().getValueAt(rownum, 0).toString()+"'";
				ResultSet rs = statement.executeQuery(str);
				if(rs.next())
				{
					int add = num+Integer.parseInt(rs.getString(1));
					System.out.println(add);
					String sql = "update 2014302580187_userInfo set number='"+String.valueOf(add)+"' where name='"+table.getModel().getValueAt(rownum, 0).toString()+"'";
					statement.execute(sql);
				}
				else 
				{
					System.out.println(table.getModel().getValueAt(rownum, 0).toString());
					String sql = "Insert into 2014302580187_userInfo (name,eat,drink,live,hobby,number) values (" 
				                  +"'"+table.getModel().getValueAt(rownum, 0).toString()+"',"
				                  +"'"+table.getModel().getValueAt(rownum, 1).toString()+"',"
				                  +"'"+table.getModel().getValueAt(rownum, 2).toString()+"',"
				                  +"'"+table.getModel().getValueAt(rownum, 3).toString()+"',"
				                  +"'"+table.getModel().getValueAt(rownum, 4).toString()+"',"
				                  +"'"+table.getModel().getValueAt(rownum, 5).toString()+"'"
				                  +")";
					statement.execute(sql);
				}
			}
			statement.execute("truncate table 2014302580187_cart");
			MainGUI_2014302580187.infoReader.setPetsCart(true);
			frame.cartPane.setVisible(false);					
			frame.contentPane.setVisible(true);
			frame.setContentPane(frame.contentPane);
			frame.setCartPane();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}

//转至购物车
class CartButtonController implements ActionListener
{
	JTable table;
	InfoReader infoReader;
	public CartButtonController(JTable table) {
		// TODO Auto-generated constructor stub
		this.table = table;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		try {
			
			java.sql.Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			java.sql.Statement statement = connection.createStatement();
			
			int rownum = 0;
			for(;rownum<table.getRowCount();rownum++)
			{
				int num = Integer.parseInt(table.getModel().getValueAt(rownum,6).toString());
				if(num==0)
					continue;
				String str = "select number from 2014302580187_cart where name='"+table.getModel().getValueAt(rownum, 0).toString()+"'";
				ResultSet rs = statement.executeQuery(str);
				if(rs.next())
				{
					int add = num+Integer.parseInt(rs.getString(1));
					System.out.println(add);
					String sql = "update 2014302580187_cart set number='"+String.valueOf(add)+"' where name='"+table.getModel().getValueAt(rownum, 0).toString()+"'";
					statement.execute(sql);
				}
				else 
				{
					System.out.println(table.getModel().getValueAt(rownum, 0).toString());
					String sql = "Insert into 2014302580187_cart (name,eat,drink,live,hobby,number) values (" 
				                  +"'"+table.getModel().getValueAt(rownum, 0).toString()+"',"
				                  +"'"+table.getModel().getValueAt(rownum, 1).toString()+"',"
				                  +"'"+table.getModel().getValueAt(rownum, 2).toString()+"',"
				                  +"'"+table.getModel().getValueAt(rownum, 3).toString()+"',"
				                  +"'"+table.getModel().getValueAt(rownum, 4).toString()+"',"
				                  +"'"+table.getModel().getValueAt(rownum, 6).toString()+"'"
				                  +")";
					statement.execute(sql);
				}
			}
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}

//登录键事件
class LoginButtonController implements ActionListener
{
	String userName;
	String password;
	MainGUI_2014302580187 frame;
	
	public LoginButtonController(MainGUI_2014302580187 frame) {
		// TODO Auto-generated constructor stub
		this.frame = frame;
	}
	
	@Override
	public void actionPerformed(ActionEvent e){
		// TODO Auto-generated method stub
		try {
			java.sql.Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			java.sql.Statement statement = connection.createStatement();
			userName = MainGUI_2014302580187.name.getText();
			password = MainGUI_2014302580187.password.getText();
			MainGUI_2014302580187.userName = userName;
			MainGUI_2014302580187.lblNewLabel_2.setText(userName);
			String sql = "select password from 2014302580187_account where userName='"+userName+"'";
			ResultSet rs = statement.executeQuery(sql);
			if(rs.next())
			{
				if(rs.getString(1).equals(password))
					{
		            frame.Login();
					}
				else 
				{
					System.out.println("密码错误！");
				}
			}
			else
			{
				System.out.println("不存在该用户");
			}
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}


//注册事件
class RegistButtonController implements ActionListener
{
	String userName;
	String password;
	MainGUI_2014302580187 frame;
	public RegistButtonController(MainGUI_2014302580187 frame)
	{
		this.frame = frame;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		try {
			java.sql.Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			java.sql.Statement statement = connection.createStatement();
			userName = MainGUI_2014302580187.name.getText();
			password = MainGUI_2014302580187.password.getText();
			String sql = "select * from 2014302580187_account where userName='"+userName+"'";
			ResultSet rs = statement.executeQuery(sql);
			if(rs.next())
			{
				return;
			}
			else 
				{
				String insert = "insert into 2014302580187_account values ('"+userName+"','"+password+"')";
				statement.execute(insert);		
				MainGUI_2014302580187.name.setText("");
				MainGUI_2014302580187.password.setText("");
				}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
	
}


