package silvercrux;

import java.awt.Component;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.TableCellRenderer;

//表格的编辑，可以显示按钮

class ButtonRenderer extends JButton implements TableCellRenderer
{
	
	public ButtonRenderer()
	{
		 setOpaque(true);  
	}

	@Override
	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
			int row, int column) {
		// TODO Auto-generated method stub
		return null;
	}
}

class ButtonEditor extends DefaultCellEditor
{

	JButton button;
	public JTable table;
	public ButtonEditor(JTable table,String str) {
		super(new JTextField());
		this.table = table;
		// TODO Auto-generated constructor stub
		this.setClickCountToStart(1);
		button = new JButton();
		button.addActionListener(new ButtonController(table,str));
		button.setOpaque(true);
	}
	
	@Override
	public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)  
	{ 
		this.button.setText(value.toString());
		return button;	
	}
	
	@Override
	public Object getCellEditorValue() {
		return this.button.getText();
	};
}
