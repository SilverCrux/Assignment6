package silvercrux;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class InfoReader {
	private java.sql.Connection connection;
	private java.sql.Statement statement;
	private Object[][] petsRow; //商店数据
	private Object[][] petsCart; //购物车数据
	private Object[][] userPets; //用户信息数据
	 
	public java.sql.Connection getConnection() {
		return connection;
	}

	public void setConnection(java.sql.Connection connection) {
		this.connection = connection;
	}

	public java.sql.Statement getStatement() {
		return statement;
	}

	public void setStatement(Statement statement) {
		this.statement = statement;
	}

	public Object[][] getPetsRow() {
		return petsRow;
	}

	public void setPetsRow() throws SQLException {
		String getPetsSql = "select * from 2014302580187_pet";
		ResultSet rs = statement.executeQuery(getPetsSql);
		int n = 0;
		while(rs.next())
		{
			n = rs.getRow();
		}
		petsRow = new Object[n][8];
		int rowNum = 0;
		rs = statement.executeQuery(getPetsSql);
		while(rs.next())
		{
			System.out.println(rs.getString(2).toString());
			for(int i=1;i<=8;i++)
			{
				if(i==6)
				{
					petsRow[rowNum][i-1] = "-";
					continue;
				}
				if(i==7)
				{
					petsRow[rowNum][i-1] = 0;
					continue;
				}
				if(i==8)
				{
					petsRow[rowNum][i-1] = "+";
					continue;
				}
				petsRow[rowNum][i-1] = rs.getString(i+1);
			}
			rowNum++;
		}
	}

	public Object[][] getPetsCart() throws SQLException {
		return petsCart;
	}

	public void setPetsCart(boolean isClear)
	{
		this.petsCart = new Object[0][6];
	}
	
	public void setPetsCart() throws SQLException {
		int rowNum = 0;
		ResultSet rs;
		int n=0;
		String loadCartSql = "select * from 2014302580187_cart";
		rs = statement.executeQuery(loadCartSql);
		while(rs.next())
		{
			n=rs.getRow();
		}
		rs = statement.executeQuery(loadCartSql);
		petsCart = new Object[n][6];
		while(rs.next())
		{
			//System.out.println(rs.getString(2).toString());
			for(int i=1;i<7;i++)
			{
				petsCart[rowNum][i-1] = rs.getString(i+1);
			}
			rowNum++;
		}
	}
	
	public void setUserPets() throws SQLException
	{
		int rowNum = 0;
		ResultSet rs;
		int n=0;
		String loadUserSql = "select * from 2014302580187_userInfo";
		rs = statement.executeQuery(loadUserSql);
		while(rs.next())
		{
			n=rs.getRow();
		}
		rs = statement.executeQuery(loadUserSql);
		userPets = new Object[n][6];
		while(rs.next())
		{
			//System.out.println(rs.getString(2).toString());
			for(int i=1;i<7;i++)
			{
				userPets[rowNum][i-1] = rs.getString(i+1);
			}
			rowNum++;
		}
	}
	
	
	public Object[][] getUserPets() 
	{
		return userPets;
	}
	
	@SuppressWarnings("null")
	public InfoReader() throws ClassNotFoundException
	{
		
		try {
			connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			statement = connection.createStatement();
			this.setPetsRow();
			this.setPetsCart();
			this.setUserPets();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



}
